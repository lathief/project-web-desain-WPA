<template>
<v-container class="pt-15">
    <v-row>
        <v-col lg="6">
            <h2 class="intro-text">Welcome</h2>
            <p class="description">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolore impedit similique necessitatibus voluptas quaerat praesentium consectetur asperiores. Officiis neque ab atque voluptates sequi voluptatum sint, aspernatur omnis, ipsum quidem enim!</p>
            <v-btn color="success" class="white--text mr-10" rounded>Let's Build</v-btn>
            <v-btn color="indigo" class="white--text" rounded>
                <v-icon>mdi-magnify</v-icon> Find Your Model
            </v-btn>
        </v-col>
        <v-col lg="6">
            <img width="100%" src="../assets/Hero.jpg" alt="">
        </v-col>
    </v-row>
</v-container>
    
</template>

<script>
export default {
    name: "HeroComponent"
}
</script>
<style scoped>
h2.intro-text {
    font-size: 60px;
    font-weight: bold;
    font-family: cursive;
    color: #444;
}
p.description{
    font-size: 19px;
    font-family: cursive;
    margin: 32px 0px;
    color: #444444ba;
}
</style>