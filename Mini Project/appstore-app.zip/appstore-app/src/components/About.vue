<template>
    <v-container>
        <v-row>
            <v-col lg="6">
                <img width="100%" src="../assets/About.jpg" alt="">
            </v-col>
            <v-col lg="6">
                <v-subheader class="text-h4">About</v-subheader>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim nemo aliquid blanditiis aut alias odio iste repudiandae in nobis, harum eveniet cum. Consequatur culpa aspernatur nobis quibusdam incidunt explicabo soluta!</p>
                <v-list>
                    <v-list-item>
                        <v-icon color="success" class="mr-3">mdi-check-all</v-icon>
                        <v-list-item-subtitle>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde obcaecati enim quos asperiores sit alias sint ducimus officiis, iusto, molestiae labore. Delectus ad, a natus veniam ex accusantium vitae autem?</v-list-item-subtitle>
                    </v-list-item>
                    <v-list-item>
                        <v-icon color="success" class="mr-3">mdi-check-all</v-icon>
                        <v-list-item-subtitle>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde obcaecati enim quos asperiores sit alias sint ducimus officiis, iusto, molestiae labore. </v-list-item-subtitle>
                    </v-list-item>
                    <v-list-item>
                        <v-icon color="success" class="mr-3">mdi-check-all</v-icon>
                        <v-list-item-subtitle>Lorem ipsum dolor sit amet consectetur adipisicing elit.</v-list-item-subtitle>
                    </v-list-item> 
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus tempora iure, adipisci quas molestiae nesciunt. Illum molestiae dolorum consequatur enim assumenda impedit vitae aut, quisquam ipsum facilis dolorem? Amet, quasi.</p>
                </v-list>
                
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
export default {
    name: "About"
}
</script>

<style scoped>

</style>